package com.wcag.wcagChecker;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import com.wcag.wcagChecker.model.AccessibilityIssue;
import com.wcag.wcagChecker.model.ImageAltData;
import com.wcag.wcagChecker.report.HtmlReportGenerator;
import com.wcag.wcagChecker.validator.PdfWcagValidator;

import org.apache.pdfbox.pdmodel.PDDocument;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

public class WebServer {

    public static void main(String[] args) throws Exception {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", new UploadPageHandler());
        server.createContext("/validate", new ValidateHandler());
        server.start();
        System.out.println("WCAG Checker running -> http://localhost:" + port);
    }

    // ------------------------------------------------------------------ upload page

    static class UploadPageHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestURI().getPath().equals("/")) {
                exchange.sendResponseHeaders(404, -1);
                return;
            }
            byte[] bytes = UPLOAD_PAGE.getBytes("UTF-8");
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        }
    }

    // ------------------------------------------------------------------ validate endpoint

    static class ValidateHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }
            String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
            File tmpPdf = null;
            File tmpReport = null;
            try {
                byte[] pdfBytes = extractPdfBytes(exchange.getRequestBody(), contentType);
                tmpPdf = File.createTempFile("wcag_upload_", ".pdf");
                tmpPdf.deleteOnExit();
                Files.write(tmpPdf.toPath(), pdfBytes);

                PDDocument document = PDDocument.load(tmpPdf);
                List<AccessibilityIssue> issues = PdfWcagValidator.validate(document);
                List<ImageAltData> images = PdfWcagValidator.extractImagesWithAlt(document);

                tmpReport = File.createTempFile("wcag_report_", ".html");
                tmpReport.deleteOnExit();
                HtmlReportGenerator.generate(issues, tmpPdf, tmpReport, images);
                document.close();

                // Inject a "back" banner and serve
                String report = new String(Files.readAllBytes(tmpReport.toPath()), "UTF-8");
                report = report.replace("<body>", "<body>" + BACK_BANNER);

                byte[] response = report.getBytes("UTF-8");
                exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
                exchange.sendResponseHeaders(200, response.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response);
                }
            } catch (Exception e) {
                String msg = "<p style='color:red;font-family:sans-serif;padding:20px'>"
                        + "<strong>Error:</strong> " + escapeHtml(e.getMessage()) + "</p>";
                byte[] response = msg.getBytes("UTF-8");
                exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
                exchange.sendResponseHeaders(500, response.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response);
                }
            } finally {
                if (tmpPdf != null) tmpPdf.delete();
                if (tmpReport != null) tmpReport.delete();
            }
        }
    }

    // ------------------------------------------------------------------ multipart parser

    static byte[] extractPdfBytes(InputStream inputStream, String contentType) throws IOException {
        String boundary = null;
        for (String part : contentType.split(";")) {
            String t = part.trim();
            if (t.startsWith("boundary=")) {
                boundary = t.substring("boundary=".length()).trim();
                break;
            }
        }
        if (boundary == null) throw new IOException("No boundary found in Content-Type");

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = inputStream.read(buf)) != -1) baos.write(buf, 0, n);
        byte[] body = baos.toByteArray();

        // Skip past the first part headers (ends at \r\n\r\n)
        byte[] headerEnd = "\r\n\r\n".getBytes("ISO-8859-1");
        int headerEndPos = indexOf(body, headerEnd, 0);
        if (headerEndPos == -1) throw new IOException("Malformed multipart: no header terminator");
        int dataStart = headerEndPos + 4;

        // File data ends before the next boundary marker
        byte[] closing = ("\r\n--" + boundary).getBytes("ISO-8859-1");
        int dataEnd = indexOf(body, closing, dataStart);
        if (dataEnd == -1) throw new IOException("Malformed multipart: no closing boundary");

        return Arrays.copyOfRange(body, dataStart, dataEnd);
    }

    private static int indexOf(byte[] data, byte[] pattern, int start) {
        outer:
        for (int i = start; i <= data.length - pattern.length; i++) {
            for (int j = 0; j < pattern.length; j++) {
                if (data[i + j] != pattern[j]) continue outer;
            }
            return i;
        }
        return -1;
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // ------------------------------------------------------------------ HTML strings

    private static final String BACK_BANNER =
        "<div style='background:#1a56db;color:white;padding:12px 24px;display:flex;" +
        "align-items:center;gap:16px;font-family:-apple-system,BlinkMacSystemFont,sans-serif'>" +
        "<a href='/' style='color:white;text-decoration:none;font-size:14px;font-weight:600;" +
        "background:rgba(255,255,255,0.2);padding:6px 14px;border-radius:6px'>&#8592; Validate another PDF</a>" +
        "<span style='font-size:15px;font-weight:600'>WCAG 2.1 Accessibility Report</span></div>";

    private static final String UPLOAD_PAGE =
        "<!DOCTYPE html>\n" +
        "<html lang='en'>\n" +
        "<head>\n" +
        "  <meta charset='UTF-8'>\n" +
        "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>\n" +
        "  <title>WCAG PDF Accessibility Checker</title>\n" +
        "  <style>\n" +
        "    *{box-sizing:border-box;margin:0;padding:0}\n" +
        "    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;\n" +
        "         background:#f0f4f8;min-height:100vh;display:flex;\n" +
        "         align-items:center;justify-content:center}\n" +
        "    .card{background:#fff;border-radius:14px;padding:48px;\n" +
        "          width:100%;max-width:520px;\n" +
        "          box-shadow:0 4px 32px rgba(0,0,0,.10)}\n" +
        "    .logo{font-size:26px;font-weight:700;color:#1a56db;margin-bottom:6px}\n" +
        "    .sub{color:#6b7280;font-size:14px;margin-bottom:36px}\n" +
        "    .drop{border:2px dashed #d1d5db;border-radius:10px;padding:48px 24px;\n" +
        "          text-align:center;cursor:pointer;transition:.2s;background:#f9fafb}\n" +
        "    .drop:hover,.drop.over{border-color:#1a56db;background:#eff6ff}\n" +
        "    .drop-icon{font-size:44px;margin-bottom:12px}\n" +
        "    .drop-text{color:#374151;font-size:15px;font-weight:500}\n" +
        "    .drop-hint{color:#9ca3af;font-size:13px;margin-top:4px}\n" +
        "    #file-input{display:none}\n" +
        "    .chosen{margin-top:12px;font-size:13px;color:#1a56db;font-weight:500;min-height:18px}\n" +
        "    .btn{width:100%;padding:13px;background:#1a56db;color:#fff;border:none;\n" +
        "         border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;\n" +
        "         margin-top:18px;transition:.2s}\n" +
        "    .btn:hover{background:#1e429f}\n" +
        "    .btn:disabled{background:#9ca3af;cursor:not-allowed}\n" +
        "    .spin-wrap{display:none;text-align:center;margin-top:18px;\n" +
        "               color:#6b7280;font-size:13px}\n" +
        "    .spin-wrap.on{display:block}\n" +
        "    .ring{border:3px solid #e5e7eb;border-top-color:#1a56db;border-radius:50%;\n" +
        "          width:30px;height:30px;animation:spin .8s linear infinite;\n" +
        "          margin:0 auto 8px}\n" +
        "    @keyframes spin{to{transform:rotate(360deg)}}\n" +
        "    .err{color:#dc2626;background:#fef2f2;border:1px solid #fecaca;\n" +
        "         padding:10px 14px;border-radius:8px;font-size:13px;\n" +
        "         margin-top:14px;display:none}\n" +
        "    .badges{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:28px}\n" +
        "    .badge{background:#eff6ff;color:#1a56db;font-size:11px;font-weight:600;\n" +
        "           padding:3px 9px;border-radius:20px}\n" +
        "  </style>\n" +
        "</head>\n" +
        "<body>\n" +
        "  <div class='card'>\n" +
        "    <div class='logo'>&#9673;&nbsp;WCAG Checker</div>\n" +
        "    <div class='sub'>PDF Accessibility Validator &mdash; WCAG 2.1</div>\n" +
        "    <div class='badges'>\n" +
        "      <span class='badge'>Alt Text</span>\n" +
        "      <span class='badge'>Headings</span>\n" +
        "      <span class='badge'>Tables</span>\n" +
        "      <span class='badge'>Forms</span>\n" +
        "      <span class='badge'>Links</span>\n" +
        "      <span class='badge'>Language</span>\n" +
        "      <span class='badge'>Bookmarks</span>\n" +
        "      <span class='badge'>Permissions</span>\n" +
        "    </div>\n" +
        "    <div class='drop' id='drop'>\n" +
        "      <div class='drop-icon'>&#128196;</div>\n" +
        "      <div class='drop-text'>Drag &amp; drop your PDF here</div>\n" +
        "      <div class='drop-hint'>or click to browse</div>\n" +
        "      <input type='file' id='file-input' accept='.pdf,application/pdf'>\n" +
        "    </div>\n" +
        "    <div class='chosen' id='chosen'></div>\n" +
        "    <button class='btn' id='btn' disabled>Validate PDF</button>\n" +
        "    <div class='spin-wrap' id='spin'><div class='ring'></div>Analysing accessibility&hellip;</div>\n" +
        "    <div class='err' id='err'></div>\n" +
        "  </div>\n" +
        "  <script>\n" +
        "    const drop=document.getElementById('drop'),\n" +
        "          fi=document.getElementById('file-input'),\n" +
        "          chosen=document.getElementById('chosen'),\n" +
        "          btn=document.getElementById('btn'),\n" +
        "          spin=document.getElementById('spin'),\n" +
        "          err=document.getElementById('err');\n" +
        "    let file=null;\n" +
        "    drop.addEventListener('click',()=>fi.click());\n" +
        "    drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('over');});\n" +
        "    drop.addEventListener('dragleave',()=>drop.classList.remove('over'));\n" +
        "    drop.addEventListener('drop',e=>{\n" +
        "      e.preventDefault();drop.classList.remove('over');\n" +
        "      const f=e.dataTransfer.files[0];\n" +
        "      if(f&&f.type==='application/pdf')pick(f);\n" +
        "      else showErr('Please drop a PDF file.');\n" +
        "    });\n" +
        "    fi.addEventListener('change',()=>{ if(fi.files[0]) pick(fi.files[0]); });\n" +
        "    function pick(f){\n" +
        "      file=f;\n" +
        "      chosen.textContent=f.name+' ('+(f.size/1024).toFixed(1)+' KB)';\n" +
        "      btn.disabled=false;\n" +
        "      err.style.display='none';\n" +
        "    }\n" +
        "    function showErr(m){err.textContent=m;err.style.display='block';}\n" +
        "    btn.addEventListener('click',async()=>{\n" +
        "      if(!file)return;\n" +
        "      btn.disabled=true;\n" +
        "      spin.classList.add('on');\n" +
        "      err.style.display='none';\n" +
        "      const fd=new FormData();\n" +
        "      fd.append('pdf',file);\n" +
        "      try{\n" +
        "        const res=await fetch('/validate',{method:'POST',body:fd});\n" +
        "        const html=await res.text();\n" +
        "        if(res.ok){document.open();document.write(html);document.close();}\n" +
        "        else{showErr('Validation error: '+html);btn.disabled=false;}\n" +
        "      }catch(e){\n" +
        "        showErr('Network error: '+e.message);btn.disabled=false;\n" +
        "      }finally{\n" +
        "        spin.classList.remove('on');\n" +
        "      }\n" +
        "    });\n" +
        "  </script>\n" +
        "</body>\n" +
        "</html>\n";
}
