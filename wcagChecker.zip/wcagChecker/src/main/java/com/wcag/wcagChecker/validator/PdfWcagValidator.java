package com.wcag.wcagChecker.validator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.pdfbox.cos.COSBase;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.documentinterchange.logicalstructure.PDStructureElement;
import org.apache.pdfbox.pdmodel.documentinterchange.logicalstructure.PDStructureTreeRoot;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDDocumentOutline;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.text.PDFTextStripper;

import com.wcag.wcagChecker.extractor.ImageExtractorEngine;
import com.wcag.wcagChecker.extractor.StructureTreeExtractor;
import com.wcag.wcagChecker.model.AccessibilityIssue;
import com.wcag.wcagChecker.model.ImageAltData;

public class PdfWcagValidator {

	public static List<AccessibilityIssue> validate(PDDocument document) throws Exception {

        List<AccessibilityIssue> issues = new ArrayList<>();


        PDDocumentCatalog catalog = document.getDocumentCatalog();
        PDStructureTreeRoot structureRoot = catalog.getStructureTreeRoot();

        /* ---------------- WCAG 1.3.1 � Info and Relationships ---------------- */

        if (structureRoot == null) {
            issues.add(new AccessibilityIssue(
                    "1.3.1", "A",
                    "PDF is not tagged (missing structure tree)",
                    "FAIL"));
        } else {
            issues.add(new AccessibilityIssue(
                    "1.3.1", "A",
                    "PDF contains a structure tree",
                    "PASS"));

            // Check for headings, lists, tables (full recursive traversal)
            boolean[] structFlags = {false, false, false}; // [hasHeading, hasList, hasTable]
            collectStructureFlags(structureRoot.getKids(), structFlags);
            boolean hasHeading = structFlags[0];
            boolean hasList = structFlags[1];
            boolean hasTable = structFlags[2];

            issues.add(new AccessibilityIssue("1.3.1", "A",
            		"List structure present",
            		hasList ? "PASS" : "WARN"));
            
            issues.add(new AccessibilityIssue("1.3.1", "A",
            		"Table structure present",
            		hasTable ? "PASS" : "WARN"));

            issues.add(new AccessibilityIssue("2.4.6", "AA",
                    "Headings present for navigation",
                    hasHeading ? "PASS" : "FAIL"));

            /* ---------------- WCAG 2.4.6 - Heading Hierarchy ---------------- */

            if (hasHeading) {
                List<Integer> headingLevels = new ArrayList<>();
                collectHeadingLevels(structureRoot.getKids(), headingLevels);
                boolean hierarchyValid = true;
                int maxSeen = 0;
                for (int level : headingLevels) {
                    if (level > maxSeen + 1) {
                        hierarchyValid = false;
                        break;
                    }
                    maxSeen = Math.max(maxSeen, level);
                }
                issues.add(new AccessibilityIssue("2.4.6", "AA",
                        "Heading hierarchy " + (hierarchyValid
                                ? "valid - no skipped levels"
                                : "invalid - heading levels are skipped"),
                        hierarchyValid ? "PASS" : "WARN"));
            }

            /* ---------------- WCAG 1.3.1 - Table Header Cells ---------------- */

            if (hasTable) {
                boolean[] hasTH = {false};
                boolean[] hasTableEl = {false};
                checkTableHeaders(structureRoot.getKids(), hasTableEl, hasTH);
                issues.add(new AccessibilityIssue("1.3.1", "A",
                        "Tables contain header cells (TH elements)",
                        hasTH[0] ? "PASS" : "WARN"));
            }

        }

        /* ---------------- WCAG 1.4.5 � Images of Text ---------------- */

        PDFTextStripper stripper = new PDFTextStripper();
        String extractedText = stripper.getText(document);
        if (extractedText.trim().isEmpty()) {
            issues.add(new AccessibilityIssue(
                    "1.4.5", "AA",
                    "PDF appears image-only (likely scanned)",
                    "FAIL"));
        }

        /* ---------------- WCAG 2.4.2 � Page Titled ---------------- */

        String title = document.getDocumentInformation().getTitle();
        issues.add(new AccessibilityIssue(
                "2.4.2", "A",
                "Document title present",
                (title == null || title.trim().isEmpty()) ? "FAIL" : "PASS"));

        /* ---------------- WCAG 3.1.1 � Language of Page ---------------- */

        String lang = catalog.getLanguage();
        issues.add(new AccessibilityIssue(
                "3.1.1", "A",
                "Document language specified",
                (lang == null || lang.trim().isEmpty()) ? "FAIL" : "PASS"));

        /* ---------------- WCAG 1.4.4 � Resize Text ---------------- */

        issues.add(new AccessibilityIssue(
                "1.4.4", "AA",
                "Text content extractable (supports resize/zoom)",
                extractedText.trim().isEmpty() ? "FAIL" : "PASS"));

        /* ---------------- WCAG 2.1.1 � Keyboard Accessible ---------------- */

        PDAcroForm form = catalog.getAcroForm();
        if (form != null && !form.getFields().isEmpty()) {
            issues.add(new AccessibilityIssue(
                    "2.1.1", "A",
                    "Interactive form fields detected (keyboard review required)",
                    "WARN"));
        } else {
            issues.add(new AccessibilityIssue(
                    "2.1.1", "A",
                    "No interactive elements detected",
                    "PASS"));
        }

        /* ---------------- WCAG 4.1.2 � Name, Role, Value ---------------- */

        if (form != null) {
            boolean missingFieldNames = false;
            for (PDField field : form.getFieldTree()) {
                if (field.getFullyQualifiedName() == null) {
                    missingFieldNames = true;
                    break;
                }
            }
            issues.add(new AccessibilityIssue(
                    "4.1.2", "A",
                    "Form fields have accessible names",
                    missingFieldNames ? "FAIL" : "PASS"));
        }


        /* ---------------- WCAG 2.4.5 - Bookmarks for long documents ---------------- */

        PDDocumentOutline outline = catalog.getDocumentOutline();
        issues.add(new AccessibilityIssue(
                "2.4.5", "AA",
                "Bookmarks present for navigation",
                outline == null ? "WARN" : "PASS"));


        /* -------------------------------------------------------
           IMAGE VALIDATIONS
        ------------------------------------------------------- */

        boolean hasText = !extractedText.trim().isEmpty();
        int totalImages = 0;
        int largeImages = 0;
        Set<String> imageHashes = new HashSet<>();
        boolean possibleImageOnly = !hasText;

        for (PDPage page : document.getPages()) {

            PDResources resources = page.getResources();

            for (COSName name : resources.getXObjectNames()) {

                PDXObject xObject = resources.getXObject(name);

                if (xObject instanceof PDImageXObject) {
                	PDImageXObject image = (PDImageXObject) xObject;

                    totalImages++;

                    // --- Image size heuristic ---
                    int width = image.getWidth();
                    int height = image.getHeight();

                    if (width > 1000 || height > 1000) {
                        largeImages++;
                    }

                    // --- Simple duplicate detection ---
                    String hash = width + "x" + height + "_" + image.getSuffix();
                    imageHashes.add(hash);
                }
            }
        }

        /* ---------------- Image Presence ---------------- */

        if (totalImages == 0) {
            issues.add(new AccessibilityIssue(
                    "1.1.1", "A",
                    "No images found in document",
                    "PASS"));
        } else {
            issues.add(new AccessibilityIssue(
                    "1.1.1", "A",
                    "Images detected in document: " + totalImages,
                    "INFO"));
        }

        /* ---------------- Image-only PDF ---------------- */

        if (possibleImageOnly && totalImages > 0) {
            issues.add(new AccessibilityIssue(
                    "1.4.5", "AA",
                    "PDF appears to be image-only (scanned document)",
                    "FAIL"));
        }

        /* ---------------- Alt Text (Heuristic) ---------------- */

        if (totalImages > 0) {
            if (structureRoot == null) {
                issues.add(new AccessibilityIssue(
                        "1.1.1", "A",
                        "Images present but no structure tree -> alt text not possible",
                        "FAIL"));
            } else {
                issues.add(new AccessibilityIssue(
                        "1.1.1", "A",
                        "Images present -> alt text must be manually verified",
                        "WARN"));
            }
        }

        /* ---------------- Large Image Detection ---------------- */

        /*if (largeImages > 0) {
            issues.add(new AccessibilityIssue(
                    "1.1.1", "A",
                    "Large images detected (" + largeImages + ") -> likely require meaningful alt text",
                    "WARN"));
        }*/

        /* ---------------- Images used as text (Heuristic) ---------------- */

        if (totalImages > 0 && !hasText) {
            issues.add(new AccessibilityIssue(
                    "1.4.5", "AA",
                    "Images may be used instead of text",
                    "FAIL"));
        } else if (totalImages > 0 && extractedText.length() < 50) {
            issues.add(new AccessibilityIssue(
                    "1.4.5", "AA",
                    "Very little text detected -> possible image-based content",
                    "WARN"));
        }

        /* ---------------- Untagged Images ---------------- */

        if (structureRoot == null && totalImages > 0) {
            issues.add(new AccessibilityIssue(
                    "1.3.1", "A",
                    "Images are not part of tagged content (no structure tree)",
                    "FAIL"));
        } else if (totalImages > 0) {
            issues.add(new AccessibilityIssue(
                    "1.3.1", "A",
                    "Verify images are tagged as Figure elements",
                    "WARN"));
        }

        /* ---------------- ALT text Validation ---------------- */

        List<ImageAltData> imageAltResult = extractImagesWithAlt(document);
        int altTextCount = 0;
        for (ImageAltData data : imageAltResult) {
        	System.out.println("$$$ pageNumber: " + data.pageNumber + ", altText: " + data.altText + ", mcid: " + data.mcid);
        	if (data.altText != null) {
        		altTextCount++;
        	}
        }

        if (totalImages == altTextCount) {
        	issues.add(new AccessibilityIssue(
                    "1.1.1", "A",
                    "All Images have ALT texts",
                    "PASS"));
        } else {
        	issues.add(new AccessibilityIssue(
                    "1.1.1", "A",
                    "ALT texts missing for " + (totalImages - altTextCount) + " out of " + totalImages + " images",
                    "FAIL"));
        }

        /* ---------------- WCAG 2.4.3 - Focus Order (Form Tab Order) ---------------- */

        if (form != null && !form.getFields().isEmpty()) {
            boolean hasStructuredTabOrder = false;
            for (PDPage page : document.getPages()) {
                COSBase tabsValue = page.getCOSObject().getDictionaryObject(COSName.getPDFName("Tabs"));
                if (tabsValue != null) {
                    hasStructuredTabOrder = true;
                    break;
                }
            }
            issues.add(new AccessibilityIssue("2.4.3", "A",
                    "Form page tab order" + (hasStructuredTabOrder
                            ? " is explicitly defined"
                            : " not defined - verify focus sequence is logical"),
                    hasStructuredTabOrder ? "PASS" : "WARN"));
        }

        /* ---------------- WCAG 2.4.4 - Link Purpose ---------------- */

        int totalLinks = 0;
        int linksWithDescription = 0;
        for (PDPage page : document.getPages()) {
            for (PDAnnotation ann : page.getAnnotations()) {
                if (ann instanceof PDAnnotationLink) {
                    totalLinks++;
                    String contents = ann.getContents();
                    if (contents != null && !contents.trim().isEmpty()) {
                        linksWithDescription++;
                    }
                }
            }
        }
        if (totalLinks > 0) {
            issues.add(new AccessibilityIssue("2.4.4", "A",
                    totalLinks + " hyperlink(s) found - " + (linksWithDescription == totalLinks
                            ? "all have descriptions"
                            : "verify all link text is descriptive"),
                    linksWithDescription == totalLinks ? "PASS" : "WARN"));
        }

        /* ---------------- Document Accessibility Permissions ---------------- */

        AccessPermission ap = document.getCurrentAccessPermission();
        issues.add(new AccessibilityIssue("1.1.1", "A",
                "Document permissions " + (ap.canExtractForAccessibility()
                        ? "allow accessibility extraction"
                        : "restrict accessibility extraction by assistive technology"),
                ap.canExtractForAccessibility() ? "PASS" : "FAIL"));

        /* ---------------- WCAG 1.1.1 - Alt Text Quality ---------------- */

        if (!imageAltResult.isEmpty()) {
            List<String> genericTerms = Arrays.asList(
                    "image", "photo", "picture", "figure", "img", "icon",
                    "logo", "graphic", "illustration", "bitmap");
            int genericAltCount = 0;
            for (ImageAltData data : imageAltResult) {
                if (data.altText != null) {
                    String lower = data.altText.trim().toLowerCase();
                    if (genericTerms.contains(lower) || lower.matches("\\d+")) {
                        genericAltCount++;
                    }
                }
            }
            if (genericAltCount > 0) {
                issues.add(new AccessibilityIssue("1.1.1", "A",
                        genericAltCount + " image(s) have generic or non-descriptive alt text",
                        "WARN"));
            } else {
                issues.add(new AccessibilityIssue("1.1.1", "A",
                        "Alt text values appear descriptive",
                        "PASS"));
            }
        }
        
        /* ---------------- WCAG 2.1.2 � No Keyboard Trap (JavaScript check) ---------------- */

        boolean hasTrappingScripts = checkForKeyboardTraps(catalog);
        if (!hasTrappingScripts) {
            issues.add(new AccessibilityIssue(
                    "2.1.2", "A",
                    "No obvious keyboard traps detected in form actions",
                    "PASS"));
        } else {
            issues.add(new AccessibilityIssue(
                    "2.1.2", "A",
                    "Form actions detected (manual review recommended for keyboard traps)",
                    "WARN"));
        }
        
        /* ---------------- WCAG 3.2.3 � Consistent Navigation ---------------- */

        if (document.getNumberOfPages() > 1) {
            boolean hasConsistentNav = checkNavigationConsistency(document);
            issues.add(new AccessibilityIssue(
                    "3.2.3", "AA",
                    "Document navigation is consistent across pages",
                    hasConsistentNav ? "PASS" : "WARN"));
        }

        issues.sort(Comparator.comparing(AccessibilityIssue::getWcagCriterion));

        return issues;
    }

    public static List<ImageAltData> extractImagesWithAlt(PDDocument document) throws Exception {

        List<ImageAltData> result = new ArrayList<>();

        PDStructureTreeRoot root = document.getDocumentCatalog().getStructureTreeRoot();
        Map<Integer, String> mcidToAlt = StructureTreeExtractor.extractAltTextByMCID(root);

        int pageIndex = 0;

        for (PDPage page : document.getPages()) {

            pageIndex++;

            ImageExtractorEngine engine =
                    new ImageExtractorEngine(pageIndex, mcidToAlt);

            engine.processPage(page);

            result.addAll(engine.images);
        }

        return result;
    }

    public static String checkAltText(String altText) {

    	System.out.println("altText: " + altText);
        if (altText == null || altText.trim().isEmpty()) {
            return "WARN";
        }

        return "PASS";
    }

    private static void collectStructureFlags(List<?> kids, boolean[] flags) {
        for (Object kid : kids) {
            if (kid instanceof PDStructureElement) {
                PDStructureElement elem = (PDStructureElement) kid;
                String type = elem.getStructureType();
                if (type != null) {
                    if (type.matches("H[1-6]") || "H".equals(type)) flags[0] = true;
                    if ("L".equals(type)) flags[1] = true;
                    if ("Table".equals(type)) flags[2] = true;
                }
                collectStructureFlags(elem.getKids(), flags);
            }
        }
    }

    private static void collectHeadingLevels(List<?> kids, List<Integer> levels) {
        for (Object kid : kids) {
            if (kid instanceof PDStructureElement) {
                PDStructureElement elem = (PDStructureElement) kid;
                String type = elem.getStructureType();
                if (type != null && type.matches("H[1-6]")) {
                    levels.add(Integer.parseInt(type.substring(1)));
                }
                collectHeadingLevels(elem.getKids(), levels);
            }
        }
    }

    private static void checkTableHeaders(List<?> kids, boolean[] hasTable, boolean[] hasTH) {
        for (Object kid : kids) {
            if (kid instanceof PDStructureElement) {
                PDStructureElement elem = (PDStructureElement) kid;
                String type = elem.getStructureType();
                if ("Table".equals(type)) hasTable[0] = true;
                if ("TH".equals(type)) hasTH[0] = true;
                checkTableHeaders(elem.getKids(), hasTable, hasTH);
            }
        }
    }

    private static boolean checkForKeyboardTraps(PDDocumentCatalog catalog) {
        try {
            PDAcroForm form = catalog.getAcroForm();
            if (form != null) {
                for (PDField field : form.getFieldTree()) {
                    // Check if field has additional action handlers
                    if (field.getCOSObject().containsKey(COSName.AA)) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            // Ignore
        }
        return false;
    }

    private static boolean checkNavigationConsistency(PDDocument document) {
        // Extract text from first and last page header areas
        try {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setStartPage(1);
            stripper.setEndPage(1);
            String firstPageText = stripper.getText(document);
            
            int numPages = document.getNumberOfPages();
            stripper.setStartPage(numPages);
            stripper.setEndPage(numPages);
            String lastPageText = stripper.getText(document);
            
            // Simple check: if structure is similar, likely consistent
            return firstPageText.length() > 0 && lastPageText.length() > 0;
        } catch (Exception e) {
            return false;
        }
    }
}
