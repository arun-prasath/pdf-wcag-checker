@echo off
set JAVA_HOME=C:\Program Files\Java\jdk1.8.0_281
set PATH=%JAVA_HOME%\bin;%PATH%
echo Starting WCAG Checker on http://localhost:8080 ...
mvn exec:java
